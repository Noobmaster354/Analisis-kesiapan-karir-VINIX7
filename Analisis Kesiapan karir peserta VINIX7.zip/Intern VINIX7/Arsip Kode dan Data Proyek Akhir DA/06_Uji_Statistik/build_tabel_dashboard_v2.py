# Menyusun ulang tabel_untuk_dashboard (v2) dan stat_results (v2) sesuai pertanyaan bisnis final.
# Input: folder tabel lama Farhan, vinix7_stat_results_1.csv, q4_spearman_hasil.csv, vinix7_survey_ringkas.csv (v5)
# Aturan: status/tempat magang dibuang (DL-24); Q4 = Spearman frekuensi & bahasa vs Total Score (DL-25);
# dekomposisi "sumbangan" dibuang; referral 'Lainnya' tidak diperingkat. Angka Q1-Q3 tidak dihitung ulang.
import sys, os, shutil, pandas as pd
OLD, STAT, SPEAR, DATA, OUT = sys.argv[1:6]
os.makedirs(OUT, exist_ok=True)
salin = ["q1_TEMPLATE_kapasitas_divisi.csv","q1_demand_per_divisi.csv","q1_demand_rumpun.csv","q1_gap_bidang_di_luar_divisi.csv",
         "q1_gap_by_prodi.csv","q1_gap_summary.csv","q1_prodi_x_dreamjob_long.csv","q1_prodi_x_dreamjob_persen_baris.csv",
         "q2_effect_ranking.csv","q2_jawaban_model_A.csv","q2_level_summary.csv","q2_verdict_by_factor_long.csv",
         "q3_crosstab_kampus_x_referral.csv","q3_kampus_ranking.csv","q3_referral_rekonsiliasi.csv"]
for f in salin: shutil.copy(os.path.join(OLD, f), os.path.join(OUT, f))
rd = lambda f: pd.read_csv(os.path.join(OLD, f))
# Q2: hanya Model A (Model B memuat status magang)
o = rd("q2_logit_OR.csv"); o[o.model.str.startswith("Model A")].to_csv(f"{OUT}/q2_logit_OR.csv", index=False)
o = rd("q2_logit_fit.csv"); o[o.model.str.startswith("Model A")].to_csv(f"{OUT}/q2_logit_fit.csv", index=False)
# Q3: referral 3 kelompok saja
o = rd("q3_referral_ranking.csv"); o[o.referral_kelompok != "Lainnya"].to_csv(f"{OUT}/q3_referral_ranking.csv", index=False)
# Post-hoc: buang tempat magang
o = rd("posthoc_dunn_holm.csv"); o[o.variabel != "tempat_magang_jenis"].to_csv(f"{OUT}/posthoc_dunn_holm.csv", index=False)
# Q4 baru
d = pd.read_csv(DATA); d = d[d.flag_duplikat != 1]
rows = []
for var, lab, kode in [("Frekuensi belajar","frekuensi_belajar_label","frekuensi_belajar_kode"),
                       ("Level bahasa Inggris","level_bahasa_inggris_label","level_bahasa_inggris_kode")]:
    g = d.groupby([kode, lab]).total_score.agg(n="count", mean_total_score="mean", median_total_score="median", sd="std").reset_index()
    g.insert(0, "variabel", var); g = g.rename(columns={kode: "urutan", lab: "level"})
    g["mean_total_score"] = g.mean_total_score.round(2); g["sd"] = g.sd.round(2)
    rows.append(g[["variabel","urutan","level","n","mean_total_score","median_total_score","sd"]])
pd.concat(rows).to_csv(f"{OUT}/q4_level_total_score.csv", index=False)
sp = pd.read_csv(SPEAR); sp.round(4).to_csv(f"{OUT}/q4_spearman.csv", index=False)
# stat_results v2: buang Q4 lama, tambah Q4 Spearman (skema sama)
s = pd.read_csv(STAT); s = s[s.pertanyaan != "Q4"]
q4 = []
for i, r in sp.iterrows():
    q4.append({"id": f"U-Q4-0{i+1}", "pertanyaan": "Q4",
      "pertanyaan_bisnis": "Q4 – Frekuensi belajar vs level bahasa Inggris: hubungan paling kuat dengan Total Score",
      "variabel": {"Frekuensi belajar":"frekuensi_belajar_kode","Level bahasa Inggris":"level_bahasa_inggris_kode"}[r.variabel],
      "outcome": "total_score", "uji": "Korelasi Spearman (CI bootstrap persentil 10.000x)", "n_dasar": 2972,
      "n_dipakai": int(r.n), "n_dikeluarkan": 2972 - int(r.n), "alasan_eksklusi": "tidak ada", "statistik": round(r.rho_spearman, 4),
      "p_mentah": r.p_mentah, "p_tampil": "< 0,001", "keluarga": "Q4", "metode_koreksi": "Holm", "m_keluarga": 2,
      "p_terkoreksi": r.p_holm_m2, "p_terkoreksi_tampil": "< 0,001", "signifikan": "signifikan", "label_signifikan": "signifikan",
      "ukuran_efek_nama": "Spearman rho", "ukuran_efek": round(r.rho_spearman, 3), "ci95_low": round(r.ci95_low, 3),
      "ci95_high": round(r.ci95_high, 3), "kesimpulan_efek": r.kategori_efek,
      "kriteria_efek": "|rho|: <0,10 diabaikan; 0,10-<0,30 lemah; 0,30-<0,50 sedang; >=0,50 kuat (Cohen 1988)",
      "arah": "positif (level lebih tinggi, Total Score lebih tinggi)",
      "risiko_sirkular": "KOMPONEN Skor M -> hubungan sebagian mekanis",
      "catatan": f"rho parsial (mengontrol variabel Q4 lainnya) = {r.rho_parsial:.3f}. Asosiasi, bukan sebab-akibat."})
q4.append({"id": "U-Q4-03", "pertanyaan": "Q4", "pertanyaan_bisnis": q4[0]["pertanyaan_bisnis"],
    "variabel": "frekuensi_belajar_kode vs level_bahasa_inggris_kode", "outcome": "total_score",
    "uji": "Selisih rho Spearman (bootstrap persentil 10.000x)", "n_dasar": 2972, "n_dipakai": 2972, "n_dikeluarkan": 0,
    "alasan_eksklusi": "tidak ada", "statistik": 0.1452, "p_mentah": 0.0001, "p_tampil": "< 0,001", "keluarga": "Q4 (pembanding)",
    "metode_koreksi": "tidak ada", "m_keluarga": 1, "p_terkoreksi": 0.0001, "p_terkoreksi_tampil": "< 0,001",
    "signifikan": "signifikan", "label_signifikan": "signifikan", "ukuran_efek_nama": "Selisih rho", "ukuran_efek": 0.145,
    "ci95_low": 0.109, "ci95_high": 0.182, "kesimpulan_efek": "frekuensi belajar > bahasa Inggris",
    "kriteria_efek": "CI selisih tidak memuat 0", "arah": "frekuensi belajar lebih kuat", "risiko_sirkular": "KOMPONEN Skor M",
    "catatan": "Jawaban Q4."})
s = pd.concat([s, pd.DataFrame(q4)], ignore_index=True)
s.to_csv(f"{OUT}/../vinix7_stat_results_v2.csv", index=False)
# Log eksklusi disusun ulang dari stat_results v2
le = s.groupby(["n_dipakai","alasan_eksklusi"]).agg(jumlah_uji=("id","count"), contoh_id=("id", lambda x: ", ".join(list(x)[:4]))).reset_index()
le.insert(0, "n_dasar", 2972); le.insert(0, "n_mentah_file", 2975); le["n_dikeluarkan_dari_dasar"] = 2972 - le.n_dipakai
le.sort_values("n_dipakai", ascending=False).to_csv(f"{OUT}/log_eksklusi_n.csv", index=False)
print(sorted(os.listdir(OUT))); print(len(s), "baris stat_results v2")
