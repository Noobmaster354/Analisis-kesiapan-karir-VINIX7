# Uji Q4 final: frekuensi belajar vs level bahasa Inggris -> hubungan dengan Total Score (Spearman)
# Input: vinix7_survey_ringkas.csv (v5, tidak diubah). Seed tetap agar hasil bisa diulang.
import sys, numpy as np, pandas as pd
from scipy import stats
src = sys.argv[1] if len(sys.argv) > 1 else "vinix7_survey_ringkas.csv"
d = pd.read_csv(src); d = d[d.flag_duplikat != 1]
x = d[["frekuensi_belajar_kode","level_bahasa_inggris_kode","total_score"]].dropna().astype(float)
A = x.values; n = len(A); B = 10000
rng = np.random.default_rng(2026)
def rho(a,b): return stats.spearmanr(a,b)[0]
r_f, p_f = stats.spearmanr(A[:,0],A[:,2]); r_b, p_b = stats.spearmanr(A[:,1],A[:,2])
boot = np.empty((B,3))
for i in range(B):
    s = A[rng.integers(0,n,n)]
    f, b = rho(s[:,0],s[:,2]), rho(s[:,1],s[:,2]); boot[i] = (f,b,f-b)
ci = np.percentile(boot,[2.5,97.5],axis=0)
p_diff = min(1.0, 2*min((boot[:,2]<=0).mean(), (boot[:,2]>=0).mean()))
p_diff = max(p_diff, 1/B)
# Holm untuk 2 uji Spearman
pr = np.array([p_f,p_b]); o = np.argsort(pr); holm = np.empty(2)
holm[o[0]] = min(1, pr[o[0]]*2); holm[o[1]] = min(1, max(holm[o[0]], pr[o[1]]*1))
def kat(r): r=abs(r); return "kuat" if r>=0.5 else "sedang" if r>=0.3 else "lemah" if r>=0.1 else "diabaikan"
R = x.rank(); c = np.corrcoef(R.values.T)
part_f = (c[0,2]-c[0,1]*c[1,2])/np.sqrt((1-c[0,1]**2)*(1-c[1,2]**2))
part_b = (c[1,2]-c[0,1]*c[0,2])/np.sqrt((1-c[0,1]**2)*(1-c[0,2]**2))
res = pd.DataFrame([
 ["Frekuensi belajar","Total Score",n,r_f,ci[0,0],ci[1,0],p_f,holm[0],kat(r_f),part_f],
 ["Level bahasa Inggris","Total Score",n,r_b,ci[0,1],ci[1,1],p_b,holm[1],kat(r_b),part_b]],
 columns=["variabel","outcome","n","rho_spearman","ci95_low","ci95_high","p_mentah","p_holm_m2","kategori_efek","rho_parsial"])
res.to_csv("q4_spearman_hasil.csv", index=False)
print(res.round(4).to_string())
print("selisih rho (frek - bahasa):", round(r_f-r_b,4), "CI", ci[:,2].round(4), "p bootstrap", p_diff)
print("rho antar prediktor:", round(c[0,1],4))
