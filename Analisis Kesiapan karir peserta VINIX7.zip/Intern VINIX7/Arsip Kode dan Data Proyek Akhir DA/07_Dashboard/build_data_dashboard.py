import pandas as pd, numpy as np
O="/mnt/user-data/outputs/"
d=pd.read_csv(O+"vinix7_survey_ringkas.csv"); d=d[d.flag_duplikat!=1].copy()
m=pd.read_excel(O+"Data_Dashboard_Final_VINIX7.xlsx",sheet_name="q3_kampus")
singkat=dict(zip(m.kampus,m.kampus_singkat))
base=pd.DataFrame({"resp_id":d.resp_id,"rumpun_prodi":d.program_studi_rumpun,
 "semester":"Semester "+d.semester.astype(str),"status_kampus":d.kampus_status})
main=base.assign(
 siap=d.is_siap.astype(int), total_score=d.total_score,
 divisi_dream_job=np.where(d.dream_job_dievaluasi==1, d.dream_job_divisi.replace({"Di luar divisi":"Di luar 13 divisi"}), "Tidak dievaluasi"),
 di_luar_divisi=pd.array(np.where(d.dream_job_dievaluasi==1,(d.dream_job_divisi=="Di luar divisi").astype(int),np.nan),dtype="Int64"),
 kampus=d.kampus_kelompok.map(singkat).fillna("Lainnya"),
 referral=d.referral_kelompok)
main.to_csv(O+"dashboard_final_vinix7.csv",index=False)

lf={1:"1 Jarang / Dasar",2:"2 Kadang / Menengah",3:"3 Rutin / Baik",4:"4 Sangat rutin / Fluent"}
q4=pd.concat([base.assign(variabel="Frekuensi belajar",tingkat=d.frekuensi_belajar_kode.map(lf),total_score=d.total_score),
              base.assign(variabel="Bahasa Inggris",tingkat=d.level_bahasa_inggris_kode.map(lf),total_score=d.total_score)])
q4.to_csv(O+"dashboard_q4_tingkat.csv",index=False)

st=pd.DataFrame([
 ("Q2",1,"Semester",0.027,None),("Q2",2,"Rumpun prodi",0.013,None),("Q2",3,"Status kampus",0.005,None),
 ("Q2",4,"Referral",None,0.001),("Q2",5,"Ikut program VINIX7",None,0.000),
 ("Q4",1,"Frekuensi belajar",0.561,None),("Q4",2,"Bahasa Inggris",0.416,None)],
 columns=["grafik","urutan","variabel","nilai_signifikan","nilai_tidak_signifikan"])
st.to_csv(O+"dashboard_statistik.csv",index=False)

print(main.shape, q4.shape)
e=main[main.divisi_dream_job!="Tidak dievaluasi"].divisi_dream_job.value_counts(normalize=True).round(4); print(e.head(3).to_dict(), len(e))
print(q4.groupby(["variabel","tingkat"]).total_score.mean().round(2).to_dict())
print(open(O+"dashboard_statistik.csv").read())
