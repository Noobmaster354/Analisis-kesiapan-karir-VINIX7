# EDA VINIX7 v2 - dibuat ulang sesuai pertanyaan bisnis final (15 Nov 2026)
# Sumber: vinix7_survey_ringkas.csv (v5, tidak diubah), flag_duplikat = 0 -> n = 2.972
# Perubahan dari EDA lama: status magang dihapus (DL-24), Q4 memakai Total Score (DL-25),
# referral "Lainnya" dikeluarkan, urutan kategori diperbaiki, judul berbentuk insight.
# Jalankan: python eda_vinix7_v2.py vinix7_survey_ringkas.csv folder_keluaran
import sys, os, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats

SRC = sys.argv[1] if len(sys.argv) > 1 else "vinix7_survey_ringkas.csv"
OUT = sys.argv[2] if len(sys.argv) > 2 else "eda_v2"
os.makedirs(OUT, exist_ok=True)

BIRU, ORANYE, ABU, TEKS, TEKS2, GRID = "#2a78d6", "#eb6834", "#b4b2a9", "#0b0b0b", "#52514e", "#e6e5e0"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.edgecolor": TEKS2,
    "axes.labelcolor": TEKS2, "xtick.color": TEKS2, "ytick.color": TEKS2, "axes.titlesize": 11,
    "axes.titleweight": "bold", "axes.titlelocation": "left", "axes.spines.top": False,
    "axes.spines.right": False, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8,
    "axes.axisbelow": True, "figure.dpi": 150, "savefig.bbox": "tight", "figure.facecolor": "white"})

d = pd.read_csv(SRC)
d = d[d.flag_duplikat != 1].copy()
N = len(d)
P_SIAP = d.is_siap.mean() * 100
id_ = lambda x, k=1: f"{x:,.{k}f}".replace(",", "X").replace(".", ",").replace("X", ".")
ribu = lambda x: f"{int(x):,}".replace(",", ".")
CATATAN = f"Sumber: survei Konsultasi Karir VINIX7, n = {ribu(N)} peserta (duplikat dikeluarkan)."

def simpan(fig, nama, catatan=CATATAN):
    fig.text(0.01, -0.02, catatan, fontsize=8, color=TEKS2, ha="left", va="top")
    fig.savefig(os.path.join(OUT, nama)); plt.close(fig); print("tersimpan", nama)

def wilson(k, n, z=1.96):
    p = k / n; den = 1 + z**2 / n; c = (p + z**2 / (2 * n)) / den
    h = z * np.sqrt(p * (1 - p) / n + z**2 / (4 * n**2)) / den
    return (c - h) * 100, (c + h) * 100

def bar_siap(ax, g, label_col, judul, horiz=False, ref=True):
    """g: DataFrame index=kategori (urutan tampil) dengan kolom n, k (jumlah siap)."""
    g = g.copy(); g["p"] = g.k / g.n * 100
    lo, hi = zip(*[wilson(k, n) for k, n in zip(g.k, g.n)])
    err = [g.p - np.array(lo), np.array(hi) - g.p]
    lab = [f"{i}\n(n={ribu(n)})" if not horiz else f"{i} (n={ribu(n)})" for i, n in zip(g.index, g.n)]
    pos = np.arange(len(g))
    if horiz:
        ax.barh(pos, g.p, color=BIRU, height=0.62, xerr=err, error_kw=dict(ecolor=TEKS2, lw=1, capsize=2))
        ax.set_yticks(pos, lab); ax.invert_yaxis(); ax.set_xlim(0, 105); ax.grid(axis="y", visible=False)
        for y, p in zip(pos, g.p): ax.text(2, y, f"{id_(p)}%", va="center", color="white", fontsize=8.5, fontweight="bold")
        if ref: ax.axvline(P_SIAP, color=TEKS2, ls="--", lw=1)
        ax.set_xlabel("% siap kerja")
    else:
        ax.bar(pos, g.p, color=BIRU, width=0.62, yerr=err, error_kw=dict(ecolor=TEKS2, lw=1, capsize=3))
        ax.set_xticks(pos, lab, fontsize=8 if len(pos) > 4 else 8.5); ax.set_ylim(0, 105); ax.grid(axis="x", visible=False)
        for x, p in zip(pos, g.p): ax.text(x, 3, f"{id_(p)}%", ha="center", color="white", fontsize=8.5, fontweight="bold")
        if ref: ax.axhline(P_SIAP, color=TEKS2, ls="--", lw=1)
        ax.set_ylabel("% siap kerja")
    ax.set_title(judul)

def agg(col, urut=None, filt=None):
    x = d if filt is None else d[filt]
    g = x.groupby(col).is_siap.agg(n="count", k="sum")
    return g.loc[urut] if urut is not None else g

IPK = ["< 2,50", "2,50 - 2,99", "3,00 - 3,49", "3,50 - 4,00"]
FREK = d.drop_duplicates("frekuensi_belajar_kode").sort_values("frekuensi_belajar_kode").frekuensi_belajar_label.tolist()
BHS = d.drop_duplicates("level_bahasa_inggris_kode").sort_values("level_bahasa_inggris_kode").level_bahasa_inggris_label.tolist()

# ---------- EDA 01: Kesiapan dan Total Score ----------
fig, (a1, a2) = plt.subplots(1, 2, figsize=(13, 4.6), gridspec_kw={"width_ratios": [1, 1.3]})
V = ["Perlu Persiapan", "Hampir Siap", "Siap Masuk Industri", "Sangat Siap"]
vc = d.verdict_kesiapan.value_counts().reindex(V)
warna = [ABU, ABU, BIRU, BIRU]
a1.bar(range(4), vc.values, color=warna, width=0.62)
for i, v in enumerate(vc.values):
    a1.text(i, v + 25, f"{ribu(v)}\n({id_(v / N * 100)}%)", ha="center", fontsize=9, color=TEKS)
a1.set_xticks(range(4), ["Perlu\nPersiapan", "Hampir\nSiap", "Siap Masuk\nIndustri", "Sangat\nSiap"])
a1.set_ylim(0, vc.max() * 1.18); a1.set_ylabel("Jumlah peserta"); a1.grid(axis="x", visible=False)
a1.set_title(f"{id_(P_SIAP)}% peserta siap kerja\n(biru = Siap Masuk Industri + Sangat Siap)", fontsize=10)
bins = np.arange(19, 101, 3)  # 61 jatuh tepat di tepi bin
a2.hist(d.total_score[d.total_score < 61], bins=bins, color=ABU, edgecolor="white", linewidth=1)
a2.hist(d.total_score[d.total_score >= 61], bins=bins, color=BIRU, edgecolor="white", linewidth=1)
a2.axvline(61, color=TEKS, ls="--", lw=1.2)
a2.text(60, a2.get_ylim()[1] * 0.92, "batas siap = 61 ", fontsize=9, color=TEKS, ha="right")
a2.set_xlabel("Total Score"); a2.set_ylabel("Jumlah peserta"); a2.grid(axis="x", visible=False)
a2.set_title(f"Total Score terpusat di 61–80\nrata-rata {id_(d.total_score.mean())}, median {id_(d.total_score.median(), 0)}", fontsize=10)
fig.suptitle("EDA 1 · Kesiapan peserta", x=0.01, ha="left", fontsize=13, fontweight="bold", y=1.03)
simpan(fig, "eda_01_kesiapan_total_score.png",
       CATATAN + " Batas verdict: ≤40 Perlu Persiapan, 41–60 Hampir Siap, 61–80 Siap Masuk Industri, ≥81 Sangat Siap.")

# ---------- EDA 02: Profil peserta (tanpa status magang) ----------
fig, ax = plt.subplots(2, 3, figsize=(15, 8.5))
def bar_n(a, s, judul, horiz=False):
    pos = np.arange(len(s))
    if horiz:
        a.barh(pos, s.values, color=BIRU, height=0.62); a.set_yticks(pos, s.index); a.invert_yaxis()
        a.grid(axis="y", visible=False)
        for y, v in zip(pos, s.values): a.text(v + s.max() * 0.01, y, ribu(v), va="center", fontsize=8.5)
        a.set_xlim(0, s.max() * 1.15)
    else:
        a.bar(pos, s.values, color=BIRU, width=0.62); a.set_xticks(pos, s.index, fontsize=9)
        a.grid(axis="x", visible=False)
        for x, v in zip(pos, s.values): a.text(x, v + s.max() * 0.01, ribu(v), ha="center", fontsize=8.5)
        a.set_ylim(0, s.max() * 1.15)
    a.set_title(judul)
sem = d.semester.value_counts().sort_index(); sem.index = [f"Smt {i}" for i in sem.index]
bar_n(ax[0, 0], sem, f"Semester 3 mendominasi ({id_(sem.iloc[2] / N * 100)}%)")
ipk = d.ipk_label.value_counts().reindex(IPK)
bar_n(ax[0, 1], ipk, f"{id_(ipk.iloc[3] / N * 100)}% ber-IPK 3,50–4,00")
ks = d.kampus_status.value_counts().reindex(["Negeri", "Swasta", "Tidak Jelas"])
bar_n(ax[0, 2], ks, f"{id_(ks.Negeri / N * 100)}% dari kampus negeri")
pr = d.program_studi_rumpun.value_counts()
bar_n(ax[1, 0], pr, "Informatika dan Ekonomi jadi prodi terbanyak", horiz=True)
rf = d.referral_kelompok.value_counts().reindex(["Tanpa referral", "DS26", "DA4", "Lainnya"])
bar_n(ax[1, 1], rf, f"{id_(rf.iloc[0] / N * 100)}% mendaftar tanpa referral")
ik = d.ikut_program_vinix7.value_counts().reindex(["ya", "tidak"]); ik.index = ["Ikut program", "Tidak ikut"]
bar_n(ax[1, 2], ik, f"{id_(ik.iloc[0] / N * 100)}% pernah ikut program VINIX7")
fig.suptitle("EDA 2 · Profil peserta", x=0.01, ha="left", fontsize=13, fontweight="bold", y=1.0)
fig.tight_layout()
simpan(fig, "eda_02_profil_peserta.png",
       CATATAN + " Referral 'Lainnya' (27) = DS23, DS25, kode personal, tidak valid; dikeluarkan dari analisis referral. Status magang tidak dianalisis (DL-24).")

# ---------- EDA 03: Q1 Dream Job vs 13 divisi ----------
ev = d[d.dream_job_dievaluasi == 1].copy()
ev["gap"] = (ev.dream_job_divisi == "Di luar divisi").astype(int)
NE = len(ev); gap = ev.gap.sum(); glo, ghi = wilson(gap, NE)
fig, (a1, a2) = plt.subplots(1, 2, figsize=(15, 6.2), gridspec_kw={"width_ratios": [1, 1]})
dv = ev.dream_job_divisi.value_counts()
pos = np.arange(len(dv)); col = [ORANYE if i == "Di luar divisi" else BIRU for i in dv.index]
a1.barh(pos, dv.values / NE * 100, color=col, height=0.66); a1.set_yticks(pos, dv.index); a1.invert_yaxis()
for y, v in zip(pos, dv.values): a1.text(v / NE * 100 + 0.3, y, f"{id_(v / NE * 100)}% ({ribu(v)})", va="center", fontsize=8.5)
a1.set_xlim(0, dv.max() / NE * 100 * 1.25); a1.set_xlabel("% peserta yang dievaluasi"); a1.grid(axis="y", visible=False)
a1.set_title(f"1 dari 5 peserta ({id_(gap / NE * 100)}%) bermimpi di luar 13 divisi;\nData Analyst divisi paling diminati ({id_(dv['Data Analyst'] / NE * 100)}%)")
gp = ev[ev.program_studi_rumpun != "Tidak Diisi"].groupby("program_studi_rumpun").gap.agg(n="count", k="sum")
gp["p"] = gp.k / gp.n * 100; gp = gp.sort_values("p", ascending=False)
lo, hi = zip(*[wilson(k, n) for k, n in zip(gp.k, gp.n)])
pos = np.arange(len(gp))
a2.barh(pos, gp.p, color=ORANYE, height=0.62, xerr=[gp.p - np.array(lo), np.array(hi) - gp.p], error_kw=dict(ecolor=TEKS2, lw=1, capsize=2))
a2.set_yticks(pos, [f"{i} (n={ribu(n)})" for i, n in zip(gp.index, gp.n)]); a2.invert_yaxis()
for y, p, h in zip(pos, gp.p, hi):
    if p >= 12: a2.text(1, y, f"{id_(p)}%", va="center", color="white", fontsize=8.5, fontweight="bold")
    else: a2.text(h + 1, y, f"{id_(p)}%", va="center", color=TEKS, fontsize=8.5, fontweight="bold")
a2.axvline(gap / NE * 100, color=TEKS2, ls="--", lw=1); a2.set_xlim(0, 100); a2.grid(axis="y", visible=False)
a2.set_xlabel("% Dream Job di luar 13 divisi (garis = rata-rata)")
top = gp.index[0]
a2.set_title(f"Gap terbesar pada prodi {top} ({id_(gp.p.iloc[0])}%),\nterkecil pada {gp.index[-1]} ({id_(gp.p.iloc[-1])}%)")
fig.suptitle("EDA 3 · Q1 Kesenjangan Dream Job vs 13 divisi VINIX7", x=0.01, ha="left", fontsize=13, fontweight="bold", y=1.02)
fig.tight_layout()
simpan(fig, "eda_03_q1_dreamjob_gap.png",
       f"n = {ribu(NE)} peserta dengan Dream Job yang bisa dievaluasi (69 belum jelas/tidak diisi dikeluarkan). Gap rate {id_(gap / NE * 100)}% (CI 95% {id_(glo)}–{id_(ghi)}%). Data hanya mengukur minat, bukan kapasitas divisi. Garis galat = CI 95% Wilson.")

# ---------- EDA 04: Q2 faktor demografis/akademis ----------
fig, ax = plt.subplots(2, 3, figsize=(18, 10))
g = agg("semester"); g.index = [f"Smt {i}" for i in g.index]
bar_siap(ax[0, 0], g, None, f"Kesiapan naik seiring semester:\n{id_(g.k.iloc[0] / g.n.iloc[0] * 100)}% (smt 1) → {id_(g.k.iloc[-1] / g.n.iloc[-1] * 100)}% (smt 5)")
g = agg("ipk_label", IPK)
bar_siap(ax[0, 1], g, None, f"IPK 3,50–4,00: {id_(g.k.iloc[3] / g.n.iloc[3] * 100)}% siap;\nIPK < 2,50: {id_(g.k.iloc[0] / g.n.iloc[0] * 100)}% (n kecil)")
g = agg("kampus_status", ["Negeri", "Swasta"])
bar_siap(ax[0, 2], g, None, f"Negeri dan swasta hampir sama:\n{id_(g.k.iloc[0] / g.n.iloc[0] * 100)}% vs {id_(g.k.iloc[1] / g.n.iloc[1] * 100)}%")
g = agg("program_studi_rumpun", filt=d.program_studi_rumpun != "Tidak Diisi"); g = g.loc[(g.k / g.n).sort_values(ascending=False).index]
bar_siap(ax[1, 0], g, None, f"{g.index[0]} paling siap ({id_(g.k.iloc[0] / g.n.iloc[0] * 100)}%),\n{g.index[-1]} paling rendah ({id_(g.k.iloc[-1] / g.n.iloc[-1] * 100)}%)", horiz=True)
g = agg("ikut_program_vinix7", ["ya", "tidak"]); g.index = ["Ikut program", "Tidak ikut"]
bar_siap(ax[1, 1], g, None, f"Ikut program VINIX7 tidak membedakan:\n{id_(g.k.iloc[0] / g.n.iloc[0] * 100)}% vs {id_(g.k.iloc[1] / g.n.iloc[1] * 100)}%")
dj = agg("dream_job_rumpun", filt=d.dream_job_dievaluasi == 1); dj = dj.loc[(dj.k / dj.n).sort_values(ascending=False).index]
bar_siap(ax[1, 2], dj, None, f"Kesiapan hampir sama di semua rumpun Dream Job\n({id_(dj.k.iloc[-1] / dj.n.iloc[-1] * 100)}–{id_(dj.k.iloc[0] / dj.n.iloc[0] * 100)}%)", horiz=True)
fig.suptitle("EDA 4 · Q2 Faktor demografis/akademis dan kesiapan", x=0.01, ha="left", fontsize=13, fontweight="bold", y=1.01)
fig.tight_layout()
simpan(fig, "eda_04_q2_faktor_demografis.png",
       CATATAN + f" Garis putus = rata-rata {id_(P_SIAP)}% siap. Garis galat = CI 95% Wilson. IPK diduga ikut menyusun skor, jadi bukan jawaban Q2. Asosiasi, bukan sebab-akibat.")

# ---------- EDA 05: Q3 kampus dan referral ----------
fig, (a1, a2) = plt.subplots(1, 2, figsize=(16, 7.4), gridspec_kw={"width_ratios": [2.4, 1]})
kv = d[d.kampus_valid == 1]; cnt = kv.kampus_resmi.value_counts(); top = cnt[cnt >= 30].index
g = kv[kv.kampus_resmi.isin(top)].groupby("kampus_resmi").is_siap.agg(n="count", k="sum")
g = g.loc[(g.k / g.n).sort_values(ascending=False).index]
bar_siap(a1, g, None, f"{g.index[0]} paling siap ({id_(g.k.iloc[0] / g.n.iloc[0] * 100)}%),\n{g.index[-1]} terendah ({id_(g.k.iloc[-1] / g.n.iloc[-1] * 100)}%) dari {len(g)} kampus", horiz=True)
r = agg("referral_kelompok", ["DS26", "DA4", "Tanpa referral"])
bar_siap(a2, r, None, f"Referral tidak membedakan\nkesiapan ({id_(r.k.min() / r.n.max() * 100 if False else (r.k / r.n).min() * 100)}–{id_((r.k / r.n).max() * 100)}%)")
fig.suptitle("EDA 5 · Q3 Kampus dan sumber referral", x=0.01, ha="left", fontsize=13, fontweight="bold", y=1.01)
fig.tight_layout()
simpan(fig, "eda_05_q3_kampus_referral.png",
       f"Kampus: {len(g)} kampus dengan ≥ 30 peserta, n = {ribu(g.n.sum())} ({id_(g.n.sum() / N * 100)}% peserta), kampus_valid = 1. Referral: 3 kelompok, 'Lainnya' (27) dikeluarkan. Garis putus = rata-rata {id_(P_SIAP)}%. Garis galat = CI 95% Wilson.")

# ---------- EDA 06: Q4 frekuensi belajar & bahasa Inggris vs Total Score ----------
r_f = stats.spearmanr(d.frekuensi_belajar_kode, d.total_score)[0]
r_b = stats.spearmanr(d.level_bahasa_inggris_kode, d.total_score)[0]
fig, (a1, a2) = plt.subplots(1, 2, figsize=(14, 5.2), sharey=True)
def mean_ci(a, col, urut, rho, judul):
    g = d.groupby(col).total_score.agg(["count", "mean", "std"]).loc[urut]
    se = g["std"] / np.sqrt(g["count"]) * 1.96; pos = np.arange(len(g))
    a.bar(pos, g["mean"], color=BIRU, width=0.62, yerr=se, error_kw=dict(ecolor=TEKS2, lw=1, capsize=3))
    for x, m in zip(pos, g["mean"]): a.text(x, m + 2.2, id_(m), ha="center", fontsize=9.5, fontweight="bold", color=TEKS)
    a.set_xticks(pos, [f"{u}\n(n={ribu(n)})" for u, n in zip(urut, g["count"])], fontsize=8.5)
    a.axhline(d.total_score.mean(), color=TEKS2, ls="--", lw=1); a.axhline(61, color=ORANYE, ls=":", lw=1.3)
    a.set_ylim(0, 100); a.grid(axis="x", visible=False); a.set_title(f"{judul}\nSpearman ρ = {id_(rho, 2)}")
mean_ci(a1, "frekuensi_belajar_label", FREK, r_f, "Frekuensi belajar: hubungan kuat")
mean_ci(a2, "level_bahasa_inggris_label", BHS, r_b, "Level bahasa Inggris: hubungan sedang")
a1.set_ylabel("Rata-rata Total Score")
fig.suptitle(f"EDA 6 · Q4 Frekuensi belajar berhubungan paling kuat dengan Total Score (ρ = {id_(r_f, 2)}), di atas bahasa Inggris (ρ = {id_(r_b, 2)})",
             x=0.01, ha="left", fontsize=12.5, fontweight="bold", y=1.04)
fig.tight_layout()
simpan(fig, "eda_06_q4_frekuensi_bahasa_total_score.png",
       CATATAN + " Garis abu putus = rata-rata Total Score; garis oranye = batas siap 61. Garis galat = CI 95% rata-rata.\nKeduanya ikut menyusun Skor M, jadi hubungan sebagian mekanis. Asosiasi, bukan sebab-akibat.")

# ---------- EDA 07: Korelasi Spearman ----------
cols = {"semester": "Semester", "ipk_kode": "IPK", "frekuensi_belajar_kode": "Frekuensi belajar",
        "level_bahasa_inggris_kode": "Bahasa Inggris", "total_score": "Total Score"}
c = d[list(cols)].rename(columns=cols).corr(method="spearman")
fig, a = plt.subplots(figsize=(7.2, 6))
im = a.imshow(c, cmap="RdBu_r", vmin=-1, vmax=1); a.grid(False)
a.set_xticks(range(len(c)), c.columns, rotation=30, ha="right"); a.set_yticks(range(len(c)), c.index)
for i in range(len(c)):
    for j in range(len(c)):
        v = c.iloc[i, j]; a.text(j, i, id_(v, 2), ha="center", va="center", fontsize=9.5,
                                 color="white" if abs(v) > 0.5 else TEKS)
fig.colorbar(im, ax=a, fraction=0.046, pad=0.04)
a.set_title("Total Score paling berhubungan dengan frekuensi belajar (0,56)\ndan bahasa Inggris (0,42); semester dan IPK lemah (0,12)")
simpan(fig, "eda_07_korelasi_spearman.png",
       CATATAN + "\nVariabel ordinal memakai kode urutannya. Frekuensi belajar dan bahasa Inggris ikut menyusun Skor M.")
